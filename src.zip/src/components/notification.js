import { subscribeUserToPush } from "./push-notification";

export const handleSubscribeClick = async (user) => {
  if (Notification.permission === "granted") {
    // Call the subscribe function with your VAPID public key
    console.log("IVAN");
    console.log(
      await subscribeUserToPush(
        user,
        "BP-JgYy2hzhTWB5LFPD_jhscLGJ2fDggIrlifMFFELzAYYyLBrthOUJ3_ldUr22PLXHNfjYCZ33An1PzN3WiaNc"
      )
    );
  }
};
