export const subscribeUserToPush = async (user, serverPublicKey) => {
  try {
    console.log(await navigator.serviceWorker.ready);
    const serviceWorkerRegistration = await navigator.serviceWorker.ready;

    const pushOptions = {
      userVisibleOnly: true,
      applicationServerKey: serverPublicKey,
    };

    const subscription = await serviceWorkerRegistration.pushManager.subscribe(
      pushOptions
    );
    console.log("Received PushSubscription:", subscription);
    // Send this subscription object to your server
    await sendSubscriptionToServer(user, subscription);
  } catch (error) {
    if (Notification.permission === "denied") {
      console.warn("Permission for notifications was denied");
    } else {
      console.error("Failed to subscribe to push", error);
    }
    console.log(error.message);
  }
};

const createSubscriptionWithUID = (user, subscriptionObject) => {
  return {
    uid: user.uid, // Assuming you have the user's UID stored in 'user'
    subscription: subscriptionObject, // The PushSubscription object
  };
};

const API_BASE_URL = "https://iot-server-o8j2.onrender.com";

const sendSubscriptionToServer = async (user, subscription) => {
  try {
    console.log("Sending subscription to server...");
    const subscriptionWithUID = createSubscriptionWithUID(user, subscription);
    const response = await fetch(`${API_BASE_URL}/subscribe`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(subscriptionWithUID),
    });

    if (!response.ok) {
      throw new Error("Failed to send subscription to server");
    }

    console.log("Subscription sent to server successfully");
    const responseData = await response.json();
    console.log(responseData);
  } catch (error) {
    console.error("Failed to send subscription to server:", error);
  }
};
