export default function Team() {
  //  await handleSubscription()
  return <div>Team</div>;
}
